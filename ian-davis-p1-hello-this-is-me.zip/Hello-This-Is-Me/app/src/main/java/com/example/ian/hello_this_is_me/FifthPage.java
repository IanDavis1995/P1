package com.example.ian.hello_this_is_me;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class FifthPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fifth_page);
    }
}
