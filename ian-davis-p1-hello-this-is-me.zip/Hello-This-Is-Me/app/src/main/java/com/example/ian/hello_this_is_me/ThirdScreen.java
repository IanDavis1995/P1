package com.example.ian.hello_this_is_me;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class ThirdScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third_screen);
    }

    /**
     * Called when the nextPageButton is clicked.
     * Create and start the FourthScreen activity.
     * @param view: The view that was clicked, in this case the nextPageButton.
     */
    public void nextPageClicked(View view) {
        Intent nextPageIntent = new Intent(this, FourthPage.class);
        startActivity(nextPageIntent);
    }
}
