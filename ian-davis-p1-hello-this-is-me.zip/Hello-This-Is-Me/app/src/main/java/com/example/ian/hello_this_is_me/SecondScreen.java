package com.example.ian.hello_this_is_me;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class SecondScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_screen);
    }

    /**
     Called when the Next Page button on this view is clicked.
     Create and start an Intent pointing to the ThirdScreen activity.

     :param view: The View object that was clicked, in this case the nextPage button.
     **/
    public void nextPageClicked(View view) {
        Intent thirdPageIntent = new Intent(this, ThirdScreen.class);
        startActivity(thirdPageIntent);
    }
}
