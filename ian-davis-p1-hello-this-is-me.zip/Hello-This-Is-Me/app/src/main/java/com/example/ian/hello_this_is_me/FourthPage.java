package com.example.ian.hello_this_is_me;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class FourthPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fourth_page);
    }

    /**
     * Called when the nextPageButton is clicked.
     * Create and start an intent to transition to the FifthPage activity.
     * @param view: The view that was clicked, in this case the nextPageButton.
     */
    public void nextPageClicked(View view) {
        Intent nextPageIntent = new Intent(this, FifthPage.class);
        startActivity(nextPageIntent);
    }
}
