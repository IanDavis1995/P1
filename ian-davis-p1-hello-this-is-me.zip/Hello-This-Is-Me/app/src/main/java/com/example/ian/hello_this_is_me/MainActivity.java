package com.example.ian.hello_this_is_me;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ViewGroup mainLayout = (ViewGroup) findViewById(R.id.activity_main);
        Button nextViewButton = new Button(this);
        TextView textView = new TextView(this);
        ImageView myPhotoView = new ImageView(this);
        LinearLayout.LayoutParams textViewLayoutParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        LinearLayout.LayoutParams photoLayoutParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );

        textViewLayoutParams.gravity = Gravity.CENTER_HORIZONTAL;

        textView.setLayoutParams(textViewLayoutParams);

        photoLayoutParams.gravity = Gravity.CENTER_HORIZONTAL;
        photoLayoutParams.weight = 1;

        myPhotoView.setContentDescription(getString(R.string.photoDescription));
        myPhotoView.setLayoutParams(photoLayoutParams);
        myPhotoView.setImageResource(R.mipmap.portrait);

        nextViewButton.setOnClickListener(this);
        nextViewButton.setText(R.string.nextPage);

        textView.setTextSize(12);
        textView.setText(R.string.WSTR);

        mainLayout.addView(textView);
        mainLayout.addView(myPhotoView);
        mainLayout.addView(nextViewButton);
    }

    /**
     Called when the nextViewButton is clicked.
     Creates the intent to transition to the second screen.

     :param view: Will be the view that was clicked on (in this case, the nextViewButton)
     */
    @Override
    public void onClick(View view) {
        Intent secondScreenIntent = new Intent(this, SecondScreen.class);
        startActivity(secondScreenIntent);
    }
}
